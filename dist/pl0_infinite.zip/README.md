PL/0 ★★★ INFINITE ★★★
========================

Main topics
-----------

* Scanner (Lexical Anayzer)
* Parser (Syntax Analyzer)
* Multi-Target compilation (Javascript, 32bit ELF, etc...)
* Angular UI including editor, compiler options and runner

More Info
---------

TODO
